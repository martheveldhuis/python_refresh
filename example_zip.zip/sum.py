def sum_two(a, b):
    return a + b
